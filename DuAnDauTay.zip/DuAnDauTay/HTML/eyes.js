$(document).ready(function(){
    alert('ok');
});